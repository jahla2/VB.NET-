﻿Public Class Form1

    Private Sub ButtonResult_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonResult.Click

        If ComboBox1.Text = "" Or ComboBox2.Text = "" Then
            MsgBox("Please do not leave any combo box empty!")
        Else
            MsgBox(LCase("You are a " & ComboBox1.Text & " enrolled in " & ComboBox2.Text))
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim x As Integer
        For x = 1 To 10
            ListBox1.Items.Add(Math.Pow(x, 2))

        Next

    End Sub

    Private ButtonClickCount As Integer = 0
    
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ButtonClickCount += 1
        Label6.Text = "Number of times clicked = " & ButtonClickCount

    End Sub

End Class

